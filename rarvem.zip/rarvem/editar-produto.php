<!doctype html>

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title style=" background-color: blueviolet;">Rarvem Bootstrap Template - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,600,600i,700,700i|Satisfy|Comic+Neue:300,300i,400,400i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/css/admin.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<?php

session_start();

include 'menu.php';
require_once('conexao.php');
require_once('Modelo/Produto.php');
require_once('Repositorio/ProdutoRepositorio.php');

$produtosRepositorio = new ProdutoRepositorio($conn);

$produto = $produtosRepositorio->listarComidaPorId($_POST['id']);

?>

</head>

<body>
    <main>
        <section class="container-admin-banner">
            <h1>Editar Produto</h1>
            <a href="index.php"><img src="assets/img/Restaurant-Logo.png" class="logo-admin" alt="logo não carregado"></a>
        <section class="container-form d-flex align-items-center justify-content-center">
            <form method="POST" action="controller/processar_editar_produto.php" id="editarForm" enctype="multipart/form-data">

                <br><label for="nome">Nome</label>
                <input type="text" id="nome" name="nomeP" value="<?= $produto->getNome(); ?>" required>

                <div class="container-radio">
                    <!-- Seu código do radio button aqui -->
                </div>

                <label for="descricao">Descrição</label>
                <input type="text" id="descricao" name="descricao" value="<?= $produto->getDescricao(); ?>" required>

                <br><label for="preco">Preço</label>
                <input type="text" id="preco" name="preco" value="<?= $produto->getPreco(); ?>" required>

                <br><?php $imagemfake = $produto->getImagem();

                // Remove a parte "C:\fakepath\" do valor (apenas no caso de navegadores baseados em Windows)
                $imagem = basename($imagemfake);

                // Agora, $imagem conterá apenas o nome do arquivo, sem a parte "C:\fakepath\"
                ?>
                <label for="imagem">Envie uma nova imagem do produto ou mantenha a imagem atual:
                    <div class="container-foto">
                        <img src="<?= $produto->getImagem(); ?>" alt="<?= $produto->getImagem(); ?>" width="200">
                        <br>
                    </div><?= $produto->getImagem(); //$imagem;
                            ?>
                </label>
                <input type="file" name="imagem" accept="image/*" id="imagem" value="<?php echo $imagem; ?>">

                <input type="hidden" name="id" id="id" value="<?= $produto->getid(); ?>">
                <br><input type="submit" name="editar" class="botao-cadastrar" value="Editar produto" />
            </form>
        </section>
    </main>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-maskmoney/3.0.2/jquery.maskMoney.min.js" integrity="sha512-Rdk63VC+1UYzGSgd3u2iadi0joUrcwX0IWp2rTh6KXFoAmgOjRS99Vynz1lJPT8dLjvo6JZOqpAHJyfCEZ5KoA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="js/index.js"></script>
</body>

</html>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title style=" background-color: blueviolet;">Rarvem Bootstrap Template - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,600,600i,700,700i|Satisfy|Comic+Neue:300,300i,400,400i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link  href="assets/css/admin.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<section id="menu" class="menu">
      <div class="container">

        <div class="section-title">
          <h2>Lista de Produtos <span> Rarvem Menu</span></h2>
        </div>

        <div class="row">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="menu-flters">
              <li data-filter="*" class="filter-active">Mostre tudo</li>
              <li data-filter=".filter-starters">Entradas</li>
              <li data-filter=".filter-salads">Saladas</li>
              <li data-filter=".filter-specialty">Especiais</li>
            </ul>
          </div>
        </div>

         <div class="row menu-container">

          <div class="col-lg-6 menu-item filter-starters">
            <div class="menu-content">
              <a href="#">Bisque de Lagosta</a><span>$5.95</span>
            </div>
            <div class="menu-ingredients">
          lagostas cozidas,Cebola, cenoura,Puerro concentrado de tomate, conhaque,vinho branco
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-specialty">
            <div class="menu-content">
              <a href="#">Lobster Bisque</a><span>$6.95</span>
            </div>
            <div class="menu-ingredients">
            Lorem, deren, trataronerada, filede,
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-starters">
            <div class="menu-content">
              <a href="#">Churrasco misto</a><span>$7.95</span>
            </div>
            <div class="menu-ingredients">
            cafta,carne de cordeiro,frango
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-salads">
            <div class="menu-content">
              <a href="#">Konafa</a><span>$8.95</span>
            </div>
            <div class="menu-ingredients">
            bolinho frito e encharcado em uma calda de nozes
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-specialty">
            <div class="menu-content">
              <a href="#">Hawawshi</a><span>$9.95</span>
            </div>
            <div class="menu-ingredients">
            pão tradicional recheado com carne picada,cebola e pimenta
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-starters">
            <div class="menu-content">
              <a href="#">Mahalabiya</a><span>$4.95</span>
            </div>
            <div class="menu-ingredients">
            pudim de leite sedoso
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-salads">
            <div class="menu-content">
              <a href="#">Eggah</a><span>$9.95</span>
            </div>
            <div class="menu-ingredients">
            ovo assado com abobrinha,cebola frita,espinhafre,tomate,berinjela,pimentão verde e alho-poró
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-salads">
            <div class="menu-content">
              <a href="#">Fattah</a><span>$9.95</span>
            </div>
            <div class="menu-ingredients">
            carne de cordeiro ou de boi, cozida, servido com arroz e pão torrado,acompanhado com molho de tomate fresco temperado com alho
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-specialty">
            <div class="menu-content">
              <a href="#">Sayadiyah</a><span>$12.95</span>
            </div>
            <div class="menu-ingredients">
            peixe branco cozido com arroz amarelo,cebola,especiarias e molho de tomate
            </div>
          </div>

        </div> 
        
      </div>
      <div id="btn">
      <a href="admin.php" class="book-a-table-btn scrollto" >Cadastrar Produto</a>       
      </div>
 
    </section>


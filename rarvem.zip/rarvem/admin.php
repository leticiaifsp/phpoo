<!DOCTYPE html>
<html lang="pt-br">
<?php
require_once 'processar_cadastro.php';

require_once('conexao.php');
require_once('Modelo/Produto.php');
require_once('Repositorio/ProdutoRepositorio.php');

$produtoRepositorio = new ProdutoRepositorio($conn);
$produtos = $produtoRepositorio->buscarTodos();
?>

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title style=" background-color: blueviolet;">Rarvem Bootstrap Template - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,600,600i,700,700i|Satisfy|Comic+Neue:300,300i,400,400i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/css/admin.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  </head>

<section id="menu" class="menu">
  <div class="container">

    <div class="section-title">
      <h2>Lista de Produtos <span> Rarvem Menu</span></h2>
    </div>

    <div class="row menu-container">
      <?php foreach ($produtos as $produto) : ?>
        <div class="col-md-4">
          <div class="produto">
            <div>
              <img src="controller/<?= $produto->getImagem() ?>" class="img-fluid" alt="Imagem do Produto" style="width: 259px; height: 194px;">
            </div>
            <div><?= $produto->getNome(); ?></div>
            <div><?= $produto->getDescricao(); ?></div>
            <div>R$ <?= $produto->getPreco(); ?></div>
            <div class="botoes-editar-excluir">
              <form action="editar-produto.php" method="POST" style="display: inline;">
                <input type="hidden" name="id" value="<?= $produto->getid(); ?>">
                <input type="submit" class="botao-editar" value="Editar">
              </form>

              <form action="excluir-produto.php" method="POST" style="display: inline;">
                <input type="hidden" name="id" value="<?= $produto->getid(); ?>">
                <input type="submit" class="botao-excluir" value="Excluir">
              </form>
              <br>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <br><div id="btn">
     <br> <a class="book-a-table-btn scrollto" onclick="CP();">Cadastrar Produto</a>
    </div>

  </div>
</section>
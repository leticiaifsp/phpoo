<!DOCTYPE html>
<html>

<head>
    <title>Menu do Usuário</title>

    <link rel="stylesheet" href="../css/menu.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="menu">
        <div class="user-info dropdown">
           
            <div class="dropdown-content">
                <!-- Conteúdo do dropdown -->
              

             
                <!-- Use um formulário para redirecionar para admin.php -->
              

                <form id="CP" action="cadastrar-produto.php" method="post" style="display: none;">

                <input type="hidden" name="usuario" value="<?= $_SESSION['usuario']; ?>">
                <input type="hidden" name="nomeusuario" value="<?= $_SESSION['nomeusuario']; ?>">
            </form>
                <!-- Passa os dados diretamente para o JavaScript -->

            </div>
        </div>
        <!--<button class="logout-button" onclick="voltar()">Voltar</button> -->
    </div>
    <script>
        function CP() {
            document.getElementById('CP').submit();
        }
      

        
    </script>

</body>

</html>